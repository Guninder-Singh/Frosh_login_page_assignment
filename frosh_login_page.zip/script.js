
function freeAccFunc(){
  document.getElementById("popupThing").style.display = "flex";
}

document.querySelector("i.fa-sharp.fa-regular.fa-circle-xmark").addEventListener("click",() =>  document.getElementById("popupThing").style.display = "none");